# -*- coding:utf-8 -*-

from scoring.cleanning import *

name='scoring'

